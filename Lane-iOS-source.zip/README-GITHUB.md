# Lane — GitHub Actions iOS build

This project is prepared for GitHub Actions with Xcode 27.

## 1. Create a GitHub repository

Create a repository and upload the contents of this folder. For the simplest free setup, make the repository public: GitHub documents that standard GitHub-hosted runners are free and unlimited for public repositories.

## 2. Build without signing

Open **Actions → iOS build → Run workflow**.

The `build` job uses the `xcode-27` runner and produces an unsigned `Lane.xcarchive` artifact. An unsigned archive is useful for verifying compilation, but it cannot be installed on an iPhone by itself.

## 3. Build a signed IPA

To let GitHub sign the app for you, add these repository Actions secrets:

- `BUILD_CERTIFICATE_BASE64` — base64 of your `.p12` signing certificate
- `P12_PASSWORD` — password for the `.p12`
- `PROVISIONING_PROFILE_BASE64` — base64 of your development/ad-hoc `.mobileprovision`
- `KEYCHAIN_PASSWORD` — any temporary password used by the CI keychain
- `TEAM_ID` — your Apple Developer Team ID

The provisioning profile must match the bundle identifier `com.example.Lane`. You can change that identifier in `Lane.xcodeproj/project.pbxproj` and use the same identifier in your provisioning profile and the workflow export options.

After the secrets are present, the `signed` job creates `Lane.ipa` as a workflow artifact.

## Base64 commands

On a Mac/Linux machine:

```bash
base64 -i signing.p12 | tr -d '\n'
base64 -i profile.mobileprovision | tr -d '\n'
```

Keep the private certificate and provisioning profile private. Do not commit them to the repository.

## iOS 27

The workflow deliberately uses the `xcode-27` runner. Apple lists Xcode 27 as the toolchain for the iOS 27 SDK.
