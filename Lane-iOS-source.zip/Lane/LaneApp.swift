import SwiftUI

@main
struct LaneApp: App {
    @StateObject private var store = LaneStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
        }
    }
}
