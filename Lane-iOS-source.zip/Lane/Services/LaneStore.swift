import Foundation
import AVFoundation

@MainActor
final class LaneStore: ObservableObject {
    @Published var selectedTab: LaneTab = .home
    @Published var searchText = ""
    @Published var isLoggedIn = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var currentTrack: Track?
    @Published var isPlaying = false
    @Published var playlists: [Playlist] = []
    @Published var recentTracks: [Track] = []

    let player = AVPlayer()
    private let api = LaneAPI.shared
    private var token: String? { UserDefaults.standard.string(forKey: "lane.accessToken") }

    init() {
        isLoggedIn = token != nil
        configureAudioSession()
        loadDemoData()
    }

    func loadDemoData() {
        let tracks = [
            Track(id: "demo-1", title: "Agony", artist: "Yung Lean", album: "Unknown Memory", artworkURL: nil, streamURL: nil, duration: 145),
            Track(id: "demo-2", title: "Starz", artist: "Yung Lean", album: "Starz", artworkURL: nil, streamURL: nil, duration: 198),
            Track(id: "demo-3", title: "Ginseng Strip 2002", artist: "Yung Lean", album: "Unknown", artworkURL: nil, streamURL: nil, duration: 160)
        ]
        recentTracks = tracks
        playlists = [Playlist(id: "liked", title: "Liked tracks", subtitle: "Your favorites", artworkURL: nil, tracks: tracks), Playlist(id: "demo", title: "My playlist", subtitle: "3 tracks", artworkURL: nil, tracks: tracks)]
    }

    func play(_ track: Track) {
        currentTrack = track
        isPlaying = true
        recentTracks.removeAll { $0.id == track.id }
        recentTracks.insert(track, at: 0)
        if let url = track.streamURL {
            player.replaceCurrentItem(with: AVPlayerItem(url: url))
            player.play()
        }
    }

    func togglePlay() {
        guard currentTrack != nil else { if let first = recentTracks.first { play(first) }; return }
        if isPlaying { player.pause() } else { player.play() }
        isPlaying.toggle()
    }

    func stop() { player.pause(); isPlaying = false }

    private func configureAudioSession() {
        do {
            let audio = AVAudioSession.sharedInstance()
            try audio.setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetoothA2DP])
            try audio.setActive(true)
        } catch { }
    }
}
