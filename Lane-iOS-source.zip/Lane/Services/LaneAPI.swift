import Foundation

final class LaneAPI {
    static let shared = LaneAPI()
    private let baseURL = URL(string: "https://laneapi.com")!
    private let session: URLSession
    private let decoder = JSONDecoder()

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 20
        session = URLSession(configuration: configuration)
    }

    func request<T: Decodable>(_ path: String, method: String = "GET", body: Data? = nil, token: String? = nil) async throws -> T {
        var request = URLRequest(url: baseURL.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))))
        request.httpMethod = method
        request.httpBody = body
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let token, !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
            throw URLError(.badServerResponse)
        }
        return try decoder.decode(T.self, from: data)
    }

    func streamURL(for trackID: String, token: String?) async throws -> URL {
        // The Android client resolves this through /track/stream. The exact payload can vary by server version,
        // so this method is intentionally isolated for easy adjustment when the API contract is available.
        let payload = ["trackId": trackID]
        let data = try JSONSerialization.data(withJSONObject: payload)
        let result: StreamResponse = try await request("/track/stream", method: "POST", body: data, token: token)
        guard let url = URL(string: result.url) else { throw URLError(.badURL) }
        return url
    }

    struct StreamResponse: Decodable { let url: String }
}
