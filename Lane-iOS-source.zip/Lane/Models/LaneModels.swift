import Foundation

struct Track: Identifiable, Codable, Hashable {
    let id: String
    var title: String
    var artist: String
    var album: String?
    var artworkURL: URL?
    var streamURL: URL?
    var duration: Double?
}

struct Playlist: Identifiable, Codable, Hashable {
    let id: String
    var title: String
    var subtitle: String?
    var artworkURL: URL?
    var tracks: [Track]
}

enum LaneTab: String, CaseIterable, Identifiable {
    case home, search, library, profile
    var id: String { rawValue }
    var title: String {
        switch self { case .home: "Home"; case .search: "Search"; case .library: "Library"; case .profile: "Profile" }
    }
    var icon: String {
        switch self { case .home: "house"; case .search: "magnifyingglass"; case .library: "books.vertical"; case .profile: "person.crop.circle" }
    }
}

struct HomeSection: Identifiable {
    let id = UUID()
    let title: String
    let tracks: [Track]
}
