import SwiftUI

struct MiniPlayerView: View {
    @EnvironmentObject private var store: LaneStore
    @State private var showFull = false
    var body: some View {
        if let track = store.currentTrack {
            Button { showFull = true } label: {
                HStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 8).fill(.white.opacity(0.12)).frame(width: 44, height: 44).overlay(Image(systemName: "music.note"))
                    VStack(alignment: .leading, spacing: 2) { Text(track.title).lineLimit(1); Text(track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                    Spacer()
                    Button { store.togglePlay() } label: { Image(systemName: store.isPlaying ? "pause.fill" : "play.fill").frame(width: 42, height: 42) }.buttonStyle(.plain)
                }.padding(.horizontal).padding(.vertical, 8)
            }.buttonStyle(.plain).fullScreenCover(isPresented: $showFull) { FullPlayerView() }
        }
    }
}

struct FullPlayerView: View {
    @EnvironmentObject private var store: LaneStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 28) {
                HStack { Button { dismiss() } label: { Image(systemName: "chevron.down") }; Spacer(); Image(systemName: "ellipsis") }.padding()
                Spacer()
                RoundedRectangle(cornerRadius: 24).fill(.white.opacity(0.08)).aspectRatio(1, contentMode: .fit).overlay(Image(systemName: "music.note").font(.system(size: 70)).foregroundStyle(.secondary)).padding(.horizontal, 24)
                if let track = store.currentTrack { VStack(alignment: .leading, spacing: 6) { Text(track.title).font(.title.bold()); Text(track.artist).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 28) }
                Slider(value: .constant(0.32)).padding(.horizontal, 28)
                HStack(spacing: 42) { Button { } label: { Image(systemName: "shuffle") }; Button { } label: { Image(systemName: "backward.end.fill") }; Button { store.togglePlay() } label: { Image(systemName: store.isPlaying ? "pause.fill" : "play.fill").font(.title).frame(width: 70, height: 70).background(.white).foregroundStyle(.black).clipShape(Circle()) }; Button { } label: { Image(systemName: "forward.end.fill") }; Button { } label: { Image(systemName: "repeat") } }.font(.title3)
                HStack { Image(systemName: "heart"); Spacer(); Image(systemName: "square.and.arrow.up"); Spacer(); Image(systemName: "arrow.down.circle") }.padding(.horizontal, 34)
                Spacer()
            }.foregroundStyle(.white)
        }
    }
}

struct TrackList: View {
    @EnvironmentObject private var store: LaneStore
    let tracks: [Track]
    var body: some View {
        LazyVStack(spacing: 0) {
            ForEach(tracks) { track in
                Button { store.play(track) } label: {
                    HStack(spacing: 12) {
                        RoundedRectangle(cornerRadius: 8).fill(.white.opacity(0.08)).frame(width: 52, height: 52).overlay(Image(systemName: "music.note"))
                        VStack(alignment: .leading, spacing: 3) { Text(track.title).font(.headline).lineLimit(1); Text(track.artist).font(.subheadline).foregroundStyle(.secondary).lineLimit(1) }
                        Spacer(); Image(systemName: "ellipsis").foregroundStyle(.secondary)
                    }.padding(.horizontal).padding(.vertical, 8)
                }.buttonStyle(.plain)
            }
        }
    }
}
