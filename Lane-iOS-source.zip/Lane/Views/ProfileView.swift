import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var store: LaneStore
    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 16) {
                        Circle().fill(.white.opacity(0.12)).frame(width: 68, height: 68).overlay(Image(systemName: "person.fill").font(.title))
                        VStack(alignment: .leading) { Text(store.isLoggedIn ? "Lane user" : "Guest").font(.title3.bold()); Text(store.isLoggedIn ? "Signed in" : "Sign in to sync your library").foregroundStyle(.secondary) }
                    }.padding(.vertical, 8)
                }
                Section("Account") {
                    NavigationLink("Premium", destination: PremiumView())
                    NavigationLink("Notifications", destination: SimplePage(title: "Notifications", icon: "bell"))
                    NavigationLink("Downloads", destination: SimplePage(title: "Downloads", icon: "arrow.down.circle"))
                }
                Section("Settings") {
                    NavigationLink("Audio quality", destination: SimplePage(title: "Audio quality", icon: "waveform"))
                    NavigationLink("Privacy", destination: SimplePage(title: "Privacy", icon: "lock"))
                    NavigationLink("About Lane", destination: SimplePage(title: "About Lane", icon: "info.circle"))
                }
            }.scrollContentBackground(.hidden).background(Color.black).navigationTitle("Profile")
        }
    }
}

struct PremiumView: View {
    var body: some View { VStack(spacing: 18) { Image(systemName: "sparkles").font(.system(size: 50)); Text("Lane Premium").font(.largeTitle.bold()); Text("Unlock premium features and an enhanced listening experience.").multilineTextAlignment(.center).foregroundStyle(.secondary); Button("View plans") { }.buttonStyle(.borderedProminent) }.padding() }
}

struct SimplePage: View { let title: String; let icon: String; var body: some View { VStack(spacing: 16) { Image(systemName: icon).font(.system(size: 48)); Text(title).font(.title.bold()); Text("This iOS module is ready to be connected to the corresponding Lane API endpoint.").multilineTextAlignment(.center).foregroundStyle(.secondary) }.padding() } }
