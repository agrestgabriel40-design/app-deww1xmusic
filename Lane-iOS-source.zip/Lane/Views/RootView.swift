import SwiftUI

struct RootView: View {
    @EnvironmentObject private var store: LaneStore

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch store.selectedTab {
                case .home: HomeView()
                case .search: SearchView()
                case .library: LibraryView()
                case .profile: ProfileView()
                }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 0) {
                    if store.currentTrack != nil { MiniPlayerView() }
                    TabBar()
                }
                .background(.ultraThinMaterial)
            }
        }
        .tint(.white)
    }
}

private struct TabBar: View {
    @EnvironmentObject private var store: LaneStore
    var body: some View {
        HStack {
            ForEach(LaneTab.allCases) { tab in
                Button { store.selectedTab = tab } label: {
                    VStack(spacing: 4) {
                        Image(systemName: tab.icon).font(.system(size: 20, weight: .medium))
                        Text(tab.title).font(.caption2)
                    }
                    .foregroundStyle(store.selectedTab == tab ? .white : .secondary)
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 10).padding(.bottom, 4)
    }
}
