import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var store: LaneStore
    var body: some View {
        NavigationStack {
            List {
                Section("Playlists") {
                    ForEach(store.playlists) { playlist in
                        NavigationLink(value: playlist) {
                            HStack {
                                RoundedRectangle(cornerRadius: 10).fill(.white.opacity(0.1)).frame(width: 52, height: 52).overlay(Image(systemName: "music.note.list"))
                                VStack(alignment: .leading) { Text(playlist.title).font(.headline); Text(playlist.subtitle ?? "").foregroundStyle(.secondary).font(.caption) }
                            }
                        }
                    }
                }
                Section("Recently played") { TrackList(tracks: store.recentTracks) }
            }
            .scrollContentBackground(.hidden).background(Color.black).navigationTitle("Library")
            .navigationDestination(for: Playlist.self) { PlaylistDetailView(playlist: $0) }
        }
    }
}

struct PlaylistDetailView: View {
    @EnvironmentObject private var store: LaneStore
    let playlist: Playlist
    var body: some View {
        List { TrackList(tracks: playlist.tracks) }
            .scrollContentBackground(.hidden).background(Color.black).navigationTitle(playlist.title)
    }
}
