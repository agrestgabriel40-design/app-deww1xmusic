import SwiftUI

struct SearchView: View {
    @EnvironmentObject private var store: LaneStore
    private var results: [Track] { store.recentTracks.filter { store.searchText.isEmpty || $0.title.localizedCaseInsensitiveContains(store.searchText) || $0.artist.localizedCaseInsensitiveContains(store.searchText) } }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    TrackList(tracks: results)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .searchable(text: $store.searchText, prompt: "Tracks, artists, albums")
            .navigationTitle("Search")
        }
    }
}
