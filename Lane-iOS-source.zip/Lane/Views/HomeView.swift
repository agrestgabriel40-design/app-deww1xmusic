import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: LaneStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Lane").font(.largeTitle.bold())
                            Text("Your music, your way").foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button { } label: { Image(systemName: "bell").font(.title3) }
                    }
                    .padding(.horizontal)

                    Text("Recently played").font(.title2.bold()).padding(.horizontal)
                    TrackList(tracks: store.recentTracks)

                    Text("Quick access").font(.title2.bold()).padding(.horizontal)
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        QuickCard(title: "Liked tracks", icon: "heart.fill")
                        QuickCard(title: "Downloads", icon: "arrow.down.circle.fill")
                        QuickCard(title: "Playlists", icon: "music.note.list")
                        QuickCard(title: "Search", icon: "magnifyingglass")
                    }.padding(.horizontal)
                }.padding(.top)
            }
            .navigationBarHidden(true)
        }
    }
}

struct QuickCard: View {
    let title: String; let icon: String
    var body: some View {
        HStack(spacing: 12) { Image(systemName: icon).font(.title3); Text(title).font(.headline); Spacer() }
            .padding().background(Color.white.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 16))
    }
}
